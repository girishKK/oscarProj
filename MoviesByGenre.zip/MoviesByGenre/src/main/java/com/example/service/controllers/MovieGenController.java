package com.example.service.controllers;

import java.util.ArrayList;
import java.util.List;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.example.service.entity.Movie;
import com.example.service.entity.MovieGen;
import com.example.service.responses.GenreResponse;
import com.example.service.services.MovieGenService;

@RestController
@RequestMapping("/moviebygenre/")
public class MovieGenController {
	
	@Autowired                 
	private ModelMapper modelMapper;

	@Autowired
	private MovieGenService serv;

	@Autowired
	RestTemplate restTemplate;
	@GetMapping("{id}")
	public ResponseEntity<?> GetById(@PathVariable String id) {

		List <MovieGen> gen = serv.getMovieGenBasedOnId(id);
		//GenreResponse resp = modelMapper.map(gen, GenreResponse.class);
 
		System.out.println(gen);
		
		List movieList = new ArrayList();
		
		for (int i  = 0; i<gen.size() ; i++) {
		   MovieGen x =  (MovieGen)gen.get(i);
		   System.out.println(x.getMovId());
		   Movie mov = restTemplate.getForObject("http://localhost:2081/movies-app/api/movies/"+x.getMovId(), Movie.class);
		   movieList.add(mov);
		}
		
		System.out.println("Movie List = " + movieList);	
		return ResponseEntity.status(HttpStatus.OK).body(movieList);
	}
	
	
	
	


}
