package com.example.service.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.example.service.entity.Movie;

@Repository
public interface MovieRepository extends JpaRepository <Movie, String > {
	
	
	@Query(nativeQuery = true, value = " SELECT  \n"
			+ "    m.*, g.gen_title\n"
			+ "FROM\n"
			+ "    movie m\n"
			+ "        LEFT JOIN\n"
			+ "    movie_genre mg ON m.mov_id = mg.mov_id\n"
			+ "        LEFT JOIN\n"
			+ "    genres g ON g.gen_id = mg.gen_id\n"
			+ "WHERE\n"
			+ "    mg.gen_id = :id\n"
			+ "ORDER BY m.mov_title;\n"
			)
	public Movie findMovieByGenreId (@Param("id") String id );
	
}
