package com.example.service.entity;

import jakarta.persistence.*;
import lombok.*;


@Getter
@Setter
@Entity
@Table(name="movie")
public class Movie {

	@Id
	@GeneratedValue(strategy  = GenerationType.IDENTITY )
	private String mov_id ;
	private String mov_title;
	private int mov_year;
	private int mov_time;
	private String mov_lang;
	private String mov_rel_country;
}
