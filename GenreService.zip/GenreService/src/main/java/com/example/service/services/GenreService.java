package com.example.service.services;

import java.util.List;

import com.example.service.entity.Genre;

public interface GenreService {
	
	 public Genre getGenreBasedOnId (String id);
	 public List<Genre> getAllGenres();
	 public Genre addGenre(Genre gen);
	 public Genre updateGenre(Genre gen);
	 public void deleteGenre(Genre gen);
}
