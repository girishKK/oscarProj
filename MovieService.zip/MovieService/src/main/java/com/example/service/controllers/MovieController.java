package com.example.service.controllers;

import java.util.List;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.example.service.responses.MovieResponse;
import com.example.service.services.MovieService;
import com.example.service.entity.Movie;

@RestController
@RequestMapping("/movies/")
public class MovieController {

	// @Autowired
	// private RestTemplate restobj;

	@Autowired
	private ModelMapper modelMapper;

	@Autowired
	private MovieService serv;

	@GetMapping("{id}")
	public ResponseEntity<MovieResponse> GetById(@PathVariable String id) {

		Movie mov = serv.getMovieBasedOnId(id);
		MovieResponse resp = modelMapper.map(mov, MovieResponse.class);

		return ResponseEntity.status(HttpStatus.OK).body(resp);
	}

	@GetMapping("/")
	public ResponseEntity<List<Movie>> GetAll() {

		List<Movie> movs = serv.getAllMovies();
		return ResponseEntity.status(HttpStatus.OK).body(movs);
	}

	@PostMapping("/")
	public ResponseEntity<Movie> Add(@RequestBody Movie movie) {

		Movie mov = serv.addMovie(movie);
		return ResponseEntity.status(HttpStatus.CREATED).body(mov);
	}

	@PutMapping("/")
	public ResponseEntity<Movie> Update(@RequestBody Movie movie) {

		Movie mov = serv.updateMovie(movie);
		return ResponseEntity.ok(mov);
	}

	@DeleteMapping("/{id}")
	public ResponseEntity<String> Delete(@PathVariable String id) {

		serv.deleteMovie(serv.getMovieBasedOnId(id));
		return ResponseEntity.ok("Deleted Successfully !");
	}

}
