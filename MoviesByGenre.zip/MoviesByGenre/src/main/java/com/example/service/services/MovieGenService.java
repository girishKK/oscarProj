package com.example.service.services;

import java.util.List;

import com.example.service.entity.MovieGen;

public interface MovieGenService {

	
	 public List<MovieGen> getMovieGenBasedOnId (String id);
	
}
