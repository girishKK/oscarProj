package com.example.service.services;

import java.util.List;


import com.example.service.entity.Movie;

public interface MovieService {

	 public Movie getMovieBasedOnId (String id);
	 public List<Movie> getAllMovies();
	 public Movie addMovie(Movie mov);
	 public Movie updateMovie(Movie mov);
	 public void deleteMovie(Movie mov);
	    
}
