package com.example.service.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.service.entity.Movie;
import com.example.service.repository.MovieRepository;

@Service
public class MovieServiceImpl implements MovieService {

	@Autowired
	private MovieRepository repo;

	@Override
	public Movie getMovieBasedOnId(String id) {
		return repo.findById(id).get();
	}

	@Override
	public List<Movie> getAllMovies() {
		return repo.findAll();
	}

	@Override
	public Movie addMovie(Movie mov) {
		return repo.save(mov);
	}

	@Override
	public Movie updateMovie(Movie mov) {
		return repo.save(mov);
	}

	@Override
	public void deleteMovie(Movie mov) {
		repo.delete(mov);

	}

}
