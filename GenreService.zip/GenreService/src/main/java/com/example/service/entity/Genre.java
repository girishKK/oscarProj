package com.example.service.entity;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.*;

@Getter
@Setter
@Entity
@Table(name="genres")
public class Genre {
	@Id
	@GeneratedValue(strategy  = GenerationType.IDENTITY )
	private String gen_id;
	private String gen_title;
	private String gen_desc;

}
