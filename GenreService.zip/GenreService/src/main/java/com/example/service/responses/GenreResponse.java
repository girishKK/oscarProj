package com.example.service.responses;

import lombok.*;

@Getter
@Setter
@ToString
public class GenreResponse {
	
	private String gen_id;
	private String gen_title;
	private String gen_desc;
}
