package com.example.service.entity;

import jakarta.persistence.*;
import lombok.*;


@Getter
@Setter
@Entity
@ToString
@Table(name="movie_genre")
public class MovieGen {
    @Id
	private String movId ;
	private String genId;

}
