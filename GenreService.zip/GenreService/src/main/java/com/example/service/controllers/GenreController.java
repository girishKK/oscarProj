package com.example.service.controllers;

import java.util.List;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.service.responses.GenreResponse;
import com.example.service.services.GenreService;
import com.example.service.entity.Genre;

@RestController
@RequestMapping("/genres/")
public class GenreController {
	
	@Autowired
	private ModelMapper modelMapper;

	@Autowired
	private GenreService serv;

	@GetMapping("{id}")
	public ResponseEntity<GenreResponse> GetById(@PathVariable String id) {

		Genre gen = serv.getGenreBasedOnId(id);
		GenreResponse resp = modelMapper.map(gen, GenreResponse.class);

		return ResponseEntity.status(HttpStatus.OK).body(resp);
	}

	@GetMapping("/")
	public ResponseEntity<List<Genre>> GetAll() {

		List<Genre> gens = serv.getAllGenres();
		return ResponseEntity.status(HttpStatus.OK).body(gens);
	}

	@PostMapping("/")
	public ResponseEntity<Genre> Add(@RequestBody Genre Genre) {

		Genre gen = serv.addGenre(Genre);
		return ResponseEntity.status(HttpStatus.CREATED).body(gen);
	}

	@PutMapping("/")
	public ResponseEntity<Genre> Update(@RequestBody Genre Genre) {

		Genre gen = serv.updateGenre(Genre);
		return ResponseEntity.ok(gen);
	}

	@DeleteMapping("/{id}")
	public ResponseEntity<String> Delete(@PathVariable String id) {

		serv.deleteGenre(serv.getGenreBasedOnId(id));
		return ResponseEntity.ok("Deleted Successfully !");
	}


}
