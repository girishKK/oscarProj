package com.example.service.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.service.entity.Genre;
import com.example.service.repository.GenreRepository;

@Service
public class GenreServiceImpl implements GenreService {

	@Autowired
	private GenreRepository repo;

	@Override
	public Genre getGenreBasedOnId(String id) {
		return repo.findById(id).get();
	}

	@Override
	public List<Genre> getAllGenres() {
		return repo.findAll();
	}

	@Override
	public Genre addGenre(Genre gen) {
		return repo.save(gen);
	}

	@Override
	public Genre updateGenre(Genre gen) {
		return repo.save(gen);
	}

	@Override
	public void deleteGenre(Genre gen) {
		repo.delete(gen);

	}

}
