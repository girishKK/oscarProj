package com.example.service.responses;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class GenreResponse {
	
	private String gen_id;
	private String gen_title;
	private String gen_desc;
}
