package com.example.service.services;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.service.entity.MovieGen;
import com.example.service.repository.MoviesByGenreRepo;

@Service
public class MovieGenImpl implements MovieGenService {

	@Autowired
	private MoviesByGenreRepo repo;

	
	public List<MovieGen> getMovieGenBasedOnId(String id) {
		
		return repo.findByGenId(id);
		
	}

}
