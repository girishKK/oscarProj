package com.example.service.responses;

import  lombok.*;


@Getter
@Setter
@ToString

public class MovieResponse {
	
	private String mov_id ;
	private String mov_title;
	private int mov_year;
	private int mov_time;
	private String mov_lang;
	private String mov_rel_country;
	private GenreResponse genre;
}


